public class CafeApp {
    public static void main(String[] args) {

        System.out.println("====================================");
        System.out.println("     WELCOME TO CAMPUS CAFE!");
        System.out.println("====================================\n");


        // =================================
        // 1. CREATE CUSTOMER OBJECTS
        // =================================

        Customer customer1 = new Customer() {
            @Override
            public double computePrice() {
                return 0;
            }
        };

        customer1.setName("Mike John Lagunero");
        customer1.setStudent(true);

        Customer customer2 =
                new Customer("  Joma Rey Tansico", false) {
                    @Override
                    public double computePrice() {
                        return 0;
                    }
                };


        // =================================
        // 2. CREATE BEVERAGE OBJECTS
        // =================================

        // Default constructor
        Beverage drink1 = new Beverage();

        drink1.setName("Iced Coffee");
        drink1.setBasePrice(80);
        drink1.setItemCode("B001");
        drink1.setSize("M");

        // Parameterized constructor
        Beverage drink2 =
                new Beverage("Milk Tea", 90, "B002", "L");


        // =================================
        // 3. CREATE PASTRY OBJECTS
        // =================================

        // Default constructor
        Pastry pastry1 = new Pastry();

        pastry1.setName("Chocolate Muffin");
        pastry1.setBasePrice(45);
        pastry1.setItemCode("P001");
        pastry1.setWarmed(true);

        // Parameterized constructor
        Pastry pastry2 =
                new Pastry("Cheese Bread", 35, "P002", false);


        // =================================
        // 4. CREATE MEAL OBJECTS
        // =================================

        // Default constructor
        Meal meal1 = new Meal();

        meal1.setName("Chicken Rice Meal");
        meal1.setBasePrice(120);
        meal1.setItemCode("M001");
        meal1.setUpsized(true);
        meal1.setExtraSides(2);

        // Parameterized constructor
        Meal meal2 =
                new Meal("Pork Rice Meal", 110,
                        "M002", false, 1);


        // =================================
        // 5. CREATE FIRST ORDER
        // =================================

        System.out.println("\n--- CUSTOMER 1 ORDER ---");

        Order order1 = new Order("ORD-001", customer1) {
            @Override
            public double computePrice() {
                return 0;
            }
        };

        order1.addItem(drink1);
        order1.addItem(pastry1);
        order1.addItem(meal1);

        // Attempt to add a fourth item
        System.out.println("\nTesting item limit:");

        order1.addItem(drink2);

        // Print first receipt
        order1.printReceipt();


        // =================================
        // 6. CREATE SECOND ORDER
        // =================================

        System.out.println("\n--- CUSTOMER 2 ORDER ---");

        Order order2 = new Order("ORD-002", customer2) {
            @Override
            public double computePrice() {
                return 0;
            }
        };
        order2.addItem(drink2);
        order2.addItem(pastry2);
        order2.addItem(meal2);

        // Print second receipt
        order2.printReceipt();


        // =================================
        // 7. TEST INVALID DATA
        // =================================

        System.out.println("\n--- TESTING INVALID DATA ---");

        drink1.setBasePrice(-100);

        meal1.setExtraSides(-2);

        drink2.setSize("XL");

        customer1.setLoyaltyPoints(-10);


        // =================================
        // 8. TEST VOUCHER
        // =================================

        System.out.println("\n--- VOUCHER TEST ---");

        double voucherTotal = order1.computeTotal(50);

        System.out.printf(
                "Total after PHP 50 voucher: PHP %.2f%n",
                voucherTotal
        );


        System.out.println("\n====================================");
        System.out.println("     THANK YOU FOR VISITING!");
        System.out.println("====================================");
    }
}
