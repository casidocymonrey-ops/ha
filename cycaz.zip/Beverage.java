
  class Beverage extends MenuItem{
    private String size;

    public Beverage() {
        super();
        this.size = "S";
    }


    public Beverage(String name, double basePrice,
                    String itemCode, String size) {

        super(name, basePrice, itemCode);
        this.size = "S";
        setSize(size);
    }


    @Override
    public double computePrice() {

        double price = basePrice;

        if (size.equals("S")) {
            price = basePrice;
        } else if (size.equals("M")) {
            price = basePrice + 15;
        } else if (size.equals("L")) {
            price = basePrice + 25;
        }

        return price;
    }


    @Override
    public String getDescription() {
        return super.getDescription() + " - Size: " + size;
    }


    public String getSize() {
        return size;
    }


    public void setSize(String size) {

        if (size != null &&
                (size.equals("S") ||
                        size.equals("M") ||
                        size.equals("L"))) {

            this.size = size;

        } else {
            System.out.println("Invalid size. Keeping old size.");
        }
    }
}
