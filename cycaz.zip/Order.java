public abstract class Order extends MenuItem {

    private Customer customer;
    private MenuItem item1;
    private MenuItem item2;
    private MenuItem item3;
    private int itemCount;
    private String orderId;
    private boolean pointsAwarded;


    public Order(String orderId, Customer customer) {

        this.orderId = orderId;
        this.customer = customer;

        this.item1 = null;
        this.item2 = null;
        this.item3 = null;

        this.itemCount = 0;
        this.pointsAwarded = false;
    }


    public boolean addItem(MenuItem item) {

        if (item == null) {
            System.out.println("Invalid menu item.");
            return false;
        }

        if (itemCount >= 3) {
            System.out.println("Order is full! Maximum of 3 items only.");
            return false;

        } else if (item1 == null) {
            item1 = item;
            itemCount++;

        } else if (item2 == null) {
            item2 = item;
            itemCount++;

        } else if (item3 == null) {
            item3 = item;
            itemCount++;
        }

        pointsAwarded = false;

        System.out.println(item.getName() + " added successfully!");

        return true;
    }


    public  double computeSubtotal() {

        double subtotal = 0;

        if (item1 != null) {
            subtotal += item1.computePrice();
        }

        if (item2 != null) {
            subtotal += item2.computePrice();
        }

        if (item3 != null) {
            subtotal += item3.computePrice();
        }

        return subtotal;
    }


    public  double computeTotal() {

        double subtotal = computeSubtotal();
        double total = subtotal;

        if (customer.isStudent()) {
            total = subtotal - (subtotal * 0.10);
        } else {
            total = subtotal;
        }

        return total;
    }


    public double computeTotal(double voucher) {

        double total = computeTotal();

        if (voucher < 0) {
            System.out.println("Invalid voucher amount.");
            voucher = 0;
        }

        total = total - voucher;

        if (total < 0) {
            total = 0;
        }

        return total;
    }


    public void printReceipt() {

        double subtotal = computeSubtotal();
        double total = computeTotal();
        double discount = subtotal - total;

        System.out.println("\n================================");
        System.out.println("       CAMPUS CAFE RECEIPT");
        System.out.println("================================");

        System.out.println("Order ID: " + orderId);
        System.out.println("Customer: " + customer.getName());

        System.out.println("Student: " +
                (customer.isStudent() ? "Yes" : "No"));

        System.out.println("--------------------------------");

        if (item1 != null) {
            System.out.println(item1.getDescription());
            System.out.printf("Price: PHP %.2f%n",
                    item1.computePrice());
        }

        if (item2 != null) {
            System.out.println(item2.getDescription());
            System.out.printf("Price: PHP %.2f%n",
                    item2.computePrice());
        }

        if (item3 != null) {
            System.out.println(item3.getDescription());
            System.out.printf("Price: PHP %.2f%n",
                    item3.computePrice());
        }

        System.out.println("--------------------------------");

        System.out.printf("Subtotal: PHP %.2f%n", subtotal);
        System.out.printf("Discount: PHP %.2f%n", discount);
        System.out.printf("Total: PHP %.2f%n", total);

        // Update loyalty points only once per unchanged order.
        if (!pointsAwarded) {
            customer.addPoints(total);
            pointsAwarded = true;
        }

        System.out.println("--------------------------------");

        System.out.println("Loyalty Points: " +
                customer.getLoyaltyPoints());

        System.out.println("================================");
        System.out.println("   Thank you for ordering!");
        System.out.println("================================\n");
    }
}
